Implemented ping simillar to the bash ping command. 
Added support for ttl specification with -t flag.
